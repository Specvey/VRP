
public class Genetique
{
	
	
	
	
	
	
	
}
