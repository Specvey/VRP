public class Main
{
	public static void main(String args[])
	{
		Genetique genetique = new Genetique("data/E-n22-k4.vrp","");
		genetique.afficherGraphe();
		
		
	}
	
	
	
	
	
	
	
}
