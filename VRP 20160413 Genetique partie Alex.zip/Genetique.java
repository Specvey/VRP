import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.graphstream.graph.Graph;

/*
 * TODO Lors des tests, faire varier pour les individus élites si on prend les 80% ou les 90% etc.
 */

/**
 * La classe Genetique correspond à la classe qui fait évoluer la population d'individu sur plusieurs générations
 * 
 * @author Xavier MAUGY & Alexandre MANCHON
 * @version 10/04/2016 Implémentation partie Alexandre MANCHON sur Genetique
 */
public class Genetique
{
	/**
	 * Taille de la population
	 * @see Genetique#population
	 */
	private int taillePopulation;
	
	/**
	 * ArrayList contenant les individus de la génération en cours
	 */
	private ArrayList<Individu> population;
	
	/**
	 * Graphe non orienté complet représentant une carte où se situe géographiquement le dépôt et les clients.
	 * Le noeud d'identifiant 0 représente le dépôt. Tous les autres noeuds représente les clients.
	 * Chaque noeud a un attribut demande qui correspond à la demande d'un client.
	 * Chaque arête représente une route entre deux clients et a un attribut poids correspondant au temps de parcours entre deux noeuds.
	 */
	private Graph g;
	
	/**
	 * Nombre de clients, le nombre de noeuds - 1 (le dépôt)
	 */
	private int nombreClients;
	
	/**
	 * La contrainte capacité du véhicule représentant la capacité maximale que peut contenir le véhicule dans une seule tournée.
	 */
	private int capaciteVehicule;
	
	/**
	 * Le nombre d'individus ayant la meilleure fitness
	 * @see Genetique#initNombreElites(ArrayList)
	 */
	private int nbrIndividusElites;
	
	/**
	 * Solution représente le meilleur individu (c'est-à-dire celui avec la meilleure fitness) valide rencontré au cours des générations
	 * @see Genetique#initSolution()
	 */
	private Individu solution;
	
	public Genetique(String nomFichier)
	{
		
	}
	
	
	/**
	 * Un individu élite est un individu qui a une fitness égale ou supérieur à 80% de la meilleure fitness.
	 * Tous les individus élites représentent donc les individus ayant la meilleure fitness.
	 * @see Genetique#nbrIndividusElites
	 */
	public void initNombreElites(ArrayList<Individu> tab)
	{
		// TODO Dans nouvelleGeneration() appeler initRangFitness avant d'appeler getNombreElites()
		// initRangFitness a été appelé précédemment et a trié tab par fitness
		
		int taille = tab.size();
		double fitnessElite = tab.get(0).getScoreFitness() * 0.8;
		nbrIndividusElites = 1;
		// initRangFitness a précédemment trié tab par fitness.
		// Il suffit de parcourir l'arraylist tab et de s'arrêter lorsque l'on a trouvé une fitness trop faible.
		while(nbrIndividusElites<taille && tab.get(nbrIndividusElites).getScoreFitness() > fitnessElite)
		{
			nbrIndividusElites++;
		}
	}

	/**
	 * Calcule pour chaque individu de tab sa fitness
	 * Tri croissant des individus en fonction du scoreFitness
	 * Parcours tab et pour chaque individu, initiliase le rang relatif en terme de fitness
	 * @param tab une arraylist d'individus
	 * @see Individu#setRangFitness(int)
	 */
	public void initRangFitness(ArrayList<Individu> tab)
	{
		// Calcule pour chaque individu de tab sa fitness
		for(Individu ind:tab)
		{
			ind.initFitness();
		}
		
		// Tri croissant des individus en fonction du scoreFitness
		Collections.sort(tab, new Comparator<Individu>()
		{
		    @Override
		    public int compare(Individu ind1, Individu ind2) {
		        return ind1.compareToScoreFitness(ind2);
		    }
		});
		
		int taille = tab.size();
		// Parcours tab et pour chaque individu, initiliase le rang relatif en terme de fitness
		for(int i=0;i<taille;i++)
		{
			tab.get(i).setRangFitness(i);
		}
	}
	
	/**
	 * Calcule pour chaque individu de tab sa diversité
	 * Tri croissant des individus en fonction du scoreDiversite
	 * Parcours tab et pour chaque individu, initiliase le rang relatif en terme de contribution à la diversité de tous les individus
	 * @param tab une arraylist d'individus
	 * @see Individu#setRangDiversite(int)
	 */
	public void initRangDiversite(ArrayList<Individu> tab)
	{
		// Calcule pour chaque individu de tab sa diversité
		for(Individu ind:tab)
		{
			ind.initDiversite(tab);
		}
		
		// Tri croissant des individus en fonction du scoreDiversite
		Collections.sort(tab, new Comparator<Individu>()
		{
		    @Override
		    public int compare(Individu ind1, Individu ind2) {
		        return ind1.compareToScoreDiversite(ind2);
		    }
		});
		
		int taille = tab.size();
		// Parcours tab et pour chaque individu, initiliase le rang relatif en terme de contribution à la diversité de tous les individus
		for(int i=0;i<taille;i++)
		{
			tab.get(i).setRangDiversite(i);
		}
	}
	
	/**
	 * initLesIncoherences initialise le nombre d'incoherences pour chaque individu de la population
	 * @see Individu#initIncoherences(Graph, int)
	 */
	public void initLesIncoherences()
	{
		for(Individu unIndividu:population)
		{
			unIndividu.initIncoherences(g, capaciteVehicule);
		}
	}
	
	/**
	 * initLesFitnessBiaisees initialise la fitnessBiaisee pour chaque individu de tab
	 * @param tab
	 * @see Individu#initFitnessBiaisee(int, int)
	 */
	public void initLesFitnessBiaisees(ArrayList<Individu> tab)
	{
		int taille = tab.size();
		for(Individu unIndividu:tab)
		{
			unIndividu.initFitnessBiaisee(nbrIndividusElites, taille);
		}
	}
	
	/**
	 * triFitnessBiaisee tri l'arraylist d'individus en fonction de la fitness biaisée
	 * @param tab
	 */
	public void triFitnessBiaisee(ArrayList<Individu> tab)
	{
		// Tri croissant des individus de tab en fonction de la fitness biaisée
		Collections.sort(tab, new Comparator<Individu>()
		{
		    @Override
		    public int compare(Individu ind1, Individu ind2) {
		        return ind1.compareToFitnessBiaisee(ind2);
		    }
		});
	}
	
	/**
	 * initSolution met à jour la solution.
	 * On parcourt toute la population
	 * Si un individu est valide et a une meilleure fitness que la solution trouvée jusqu'à présent , il devient la solution
	 * Sinon la solution reste inchangée
	 * @see Genetique#solution
	 */
	public void initSolution()
	{
		// On parcourt tous les individus
		for(Individu unIndividu:population)
		{
			// Si l'individu a une meilleure fitness que la solution et est valide
			if(unIndividu.getScoreFitness()<solution.getScoreFitness() && unIndividu.getIncoherences() == 0)
			{
				// Alors il devient la nouvelle solution
				solution = unIndividu;
			}
		}
	}
}
