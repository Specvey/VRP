public class Main
{
	public static void main(String args[])
	{
		Genetique genetique = new Genetique("data/E-n22-k4.vrp","data/parametres9.data");
		//Genetique genetique = new Genetique("data/E-n101-k14.vrp","data/parametres9.data");
		
		// genetique.afficherGraphe();
		genetique.evolution();
	}
}
